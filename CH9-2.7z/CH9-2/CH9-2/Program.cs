﻿namespace CH9_2
{
    // Box 類別宣告
    class Box
    {
        public double Width { get; private set; }
        public double Height { get; private set; }
        public double Length { get; private set; }

       
        public Box(double width, double height, double length)
        {
            Width = width;
            Height = height;
            Length = length;
        }

        public double Volume()
        {
            return Width * Height * Length;
        }
        public double Area()
        {
            return 2 * (Width * Height + Width * Length + Height * Length);
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("輸入盒子寬度：");
            double width = double.Parse(Console.ReadLine());

            Console.Write("輸入盒子高度：");
            double height = double.Parse(Console.ReadLine());

            Console.Write("輸入盒子長度：");
            double length = double.Parse(Console.ReadLine());

            Box box = new Box(width, height, length);

            Console.WriteLine($"體積：{box.Volume()}");
            Console.WriteLine($"表面積：{box.Area()}");

        }
    }
}