namespace CH8_2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int[] numbers = new int[5];
            Random rand = new Random();
         
            for (int i = 0; i < numbers.Length; i++)
            {
                numbers[i] = rand.Next(1, 201); 
            }
         
            Array.Sort(numbers);
       
            label1.Text = "�}�C: " + string.Join(", ", numbers);
        }
    
    }
}
