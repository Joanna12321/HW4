namespace CH8_4
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private int ArrMin(int[] arr)
        {
            return arr.Min();
        }
        
        private int ArrMax(int[] arr)
        {
             return arr.Max();
        }

        private void button1_Click(object sender, EventArgs e)
        {           
                int[] numbers = new int[]
                {
                    int.Parse(textBox1.Text),
                    int.Parse(textBox2.Text),
                    int.Parse(textBox3.Text),
                    int.Parse(textBox4.Text),
                    int.Parse(textBox5.Text),
                    int.Parse(textBox6.Text)
                };

                int min = ArrMin(numbers);
                int max = ArrMax(numbers);

                lblResult.Text = $"�̤p��: {min}, �̤j��: {max}";                
        }
                
       
    }
}
