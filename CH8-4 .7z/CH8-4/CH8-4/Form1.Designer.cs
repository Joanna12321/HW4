﻿namespace CH8_4
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            textBox1 = new TextBox();
            textBox2 = new TextBox();
            textBox3 = new TextBox();
            textBox4 = new TextBox();
            textBox5 = new TextBox();
            textBox6 = new TextBox();
            lblResult = new Label();
            button1 = new Button();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Microsoft JhengHei UI", 20.25F, FontStyle.Bold, GraphicsUnit.Point, 136);
            label1.Location = new Point(150, 49);
            label1.Name = "label1";
            label1.Size = new Size(193, 35);
            label1.TabIndex = 0;
            label1.Text = "請輸入6個數字";
            // 
            // textBox1
            // 
            textBox1.Font = new Font("Microsoft JhengHei UI", 15.75F, FontStyle.Regular, GraphicsUnit.Point, 136);
            textBox1.Location = new Point(24, 119);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(59, 34);
            textBox1.TabIndex = 1;
            // 
            // textBox2
            // 
            textBox2.Font = new Font("Microsoft JhengHei UI", 15.75F, FontStyle.Regular, GraphicsUnit.Point, 136);
            textBox2.Location = new Point(104, 119);
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(59, 34);
            textBox2.TabIndex = 2;
            // 
            // textBox3
            // 
            textBox3.Font = new Font("Microsoft JhengHei UI", 15.75F, FontStyle.Regular, GraphicsUnit.Point, 136);
            textBox3.Location = new Point(187, 119);
            textBox3.Name = "textBox3";
            textBox3.Size = new Size(59, 34);
            textBox3.TabIndex = 3;
            // 
            // textBox4
            // 
            textBox4.Font = new Font("Microsoft JhengHei UI", 15.75F, FontStyle.Regular, GraphicsUnit.Point, 136);
            textBox4.Location = new Point(266, 119);
            textBox4.Name = "textBox4";
            textBox4.Size = new Size(59, 34);
            textBox4.TabIndex = 4;
            // 
            // textBox5
            // 
            textBox5.Font = new Font("Microsoft JhengHei UI", 15.75F, FontStyle.Regular, GraphicsUnit.Point, 136);
            textBox5.Location = new Point(350, 119);
            textBox5.Name = "textBox5";
            textBox5.Size = new Size(59, 34);
            textBox5.TabIndex = 5;
            // 
            // textBox6
            // 
            textBox6.Font = new Font("Microsoft JhengHei UI", 15.75F, FontStyle.Regular, GraphicsUnit.Point, 136);
            textBox6.Location = new Point(436, 119);
            textBox6.Name = "textBox6";
            textBox6.Size = new Size(59, 34);
            textBox6.TabIndex = 6;
            // 
            // lblResult
            // 
            lblResult.AutoSize = true;
            lblResult.BackColor = SystemColors.ControlDarkDark;
            lblResult.Font = new Font("Microsoft JhengHei UI", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 136);
            lblResult.ForeColor = SystemColors.ControlLightLight;
            lblResult.Location = new Point(109, 278);
            lblResult.MinimumSize = new Size(300, 40);
            lblResult.Name = "lblResult";
            lblResult.Size = new Size(300, 40);
            lblResult.TabIndex = 7;
            // 
            // button1
            // 
            button1.BackColor = SystemColors.ButtonFace;
            button1.Font = new Font("Microsoft JhengHei UI", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 136);
            button1.Location = new Point(152, 207);
            button1.Name = "button1";
            button1.Size = new Size(191, 40);
            button1.TabIndex = 8;
            button1.Text = "執行";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(562, 374);
            Controls.Add(button1);
            Controls.Add(lblResult);
            Controls.Add(textBox6);
            Controls.Add(textBox5);
            Controls.Add(textBox4);
            Controls.Add(textBox3);
            Controls.Add(textBox2);
            Controls.Add(textBox1);
            Controls.Add(label1);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private TextBox textBox1;
        private TextBox textBox2;
        private TextBox textBox3;
        private TextBox textBox4;
        private TextBox textBox5;
        private TextBox textBox6;
        private Label lblResult;
        private Button button1;
    }
}
