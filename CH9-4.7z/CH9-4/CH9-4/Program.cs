﻿namespace CH9_4
{
    
    class PhoneList
    {
        public string HomePhone { get; set; }
        public string BusinessPhone { get; set; }
        public string CellPhone { get; set; }

        public PhoneList(string home, string business, string cell)
        {
            HomePhone = home;
            BusinessPhone = business;
            CellPhone = cell;
        }
    }
   
    class Cards
    {
        public string Name { get; set; }
        public string Occupation { get; set; }
        public int Age { get; set; }
        public PhoneList Phone { get; set; }
        public string Email { get; set; }

        public Cards(string name, string occupation, int age, PhoneList phone, string email)
        {
            Name = name;
            Occupation = occupation;
            Age = age;
            Phone = phone;
            Email = email;
        }

        public string GetCard()
        {
            return
            $" 姓名：{Name}\n 職業：{Occupation}\n 年齡：{Age}\n 住家電話：{Phone.HomePhone}\n 公司電話：{Phone.BusinessPhone}\n 手機：{Phone.CellPhone}\n 電子郵件：{Email}";
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            
        }
    }
}
